# -*- coding: utf-8 -*-
"""
Created on Sat Dec 12 01:15:56 2020

@author: Mohammed Jahangir Alom
Student No - R00144214
"""

import json
from itertools import product
#from probability import *
#from learning import *

import os, sys, inspect
current_dir = os.path.dirname(os.path.abspath(inspect.getfile(inspect.currentframe())))
parent_dir = os.path.dirname(current_dir)
sys.path.insert(0, parent_dir)


#Question 1.1.2
class BayesNet():
    '''
    This BayesNet class taken from the probability.py from aima-python dir.
    and modified the methods.
    '''

    def __init__(self, name):
        self.parents = []
        self.children = []
        self.name = name
        self.priorProbabilities = True#prior_probabilities
        self.probabilityTable = {}

        #adding child
    def addChild(self, child):
        self.children.append(child)

        #Adding parents
    def addParents(self, parents):
        self.parents.extend(parents)

    def set_priorProbabilities(self, priorProbabilities):
        self.priorProbabilities = priorProbabilities

    def set_probabilityTable(self, probabilityTable):
        self.probabilityTable = probabilityTable

    def priorProbabilities(self):
        return self.priorProbabilities

    def getProbability(self, value_dict):
        if self.priorProbabilities:
            key = value_dict[self.name]
        else:
            condition = self.parents + [self.name]
            key = ()
            for c in condition:
                key = key + ((c, value_dict[c]),)
            key = tuple(sorted(key))

        return self.probabilityTable[key]



class BayesNode(object):
    '''
    This BayesNode class taken from the probability.py from aima-python dir.
    and modified the methods.
    '''
    def __init__(self, structure, values, queries):
        self.variables = structure["variables"]
        self.dependencies = structure["dependencies"]
        self.conditional_probabilities = values["conditional_probabilities"]
        self.prior_probabilities = values["prior_probabilities"]
        self.queries = queries
        self.answer = []
        self.graph = {}

    #Building prior probability table. Here key is variables value
    def build_prior_probability_table(self, var):
        value_dict = self.prior_probabilities[var]
        probabilityTable = {}
        for key in value_dict:
            probabilityTable[key] = value_dict[key]

        return probabilityTable

    #Building prior probability table. Here key is sorted tuple item is variables value
    def build_conditional_probability_table(self, var):
        value_dict_arr = self.conditional_probabilities[var]
        probabilityTable = {}
        for value_dict in value_dict_arr:
            prob = value_dict['probability']

            key = ()
            for k in value_dict:
                if k != 'probability':
                    if k != 'own_value':
                        key = key + ((k, value_dict[k]),)
                    else:
                        key = key + ((var, value_dict[k]),)

            key = tuple(sorted(key))
            probabilityTable[key] = prob

        return probabilityTable

    #Building bayesian network
    def build_Bayesian_Network(self):
        #print('\n=================Question 1.1.2==================\n')
        for var in self.variables:
            node = BayesNet(var)
            self.graph[var] = node

        for var in self.prior_probabilities:
            self.graph[var].set_probabilityTable(self.build_prior_probability_table(var))
            self.graph[var].set_priorProbabilities(True)

        for var in self.dependencies:
            parents = self.dependencies[var]
            self.graph[var].addParents(parents)
            self.graph[var].set_probabilityTable(self.build_conditional_probability_table(var))
            self.graph[var].set_priorProbabilities(False)

            for p in parents:
                self.graph[p].addChild(var)
            self.printTableGraph()

    #conclusion reached based on the basis of evidence and reasoning of the variavles
    def probabilistic_inference(self):
        for i in self.queries:
            index = i["index"]
            given = i["given"]
            tofind = i["tofind"]

            fixedVariables = [x for x in given] + [x for x in tofind]
            varyingVariables = [y for y in self.variables if y not in fixedVariables]
            print(given)

            part1 = self.calculate_probability_of_likelihood_of_evidences(given, tofind, fixedVariables, varyingVariables)
            print(given)

            fixedVariables = [x for x in given]
            varyingVariables = list(set([y for y in self.variables if y not in fixedVariables] + [x for x in tofind]))
            part2 = self.calculate_probability_of_likelihood_of_evidences(given, tofind, fixedVariables, varyingVariables)
            answer =  part1 / part2
            self.answer.append({"INDEX": index, "ANSWER": answer})

        return self.answer

    #Finding the probability of hte each variables
    def get_every_probability_of_the_model(self, value_dict):
        prob_arr = []
        for var in self.graph:
            node = self.graph[var]
            prob_arr.append(node.getProbability(value_dict))
        return prob_arr

    #Calculating the probability
    def calculate_probability_of_likelihood_of_evidences(self, given, tofind, fixedVariables, varyingVariables):
        # all_variables_probability will contains all the probabilities of our individual variables
        all_variables_probability = []
        table_of_variables = given.copy()
        table_of_variables.update(tofind)

        for var in varyingVariables:
            table_of_variables[var] = 'True'

        get_all_possible_truth_values = self.data_perimeter(table_of_variables, len(varyingVariables))

        # Here each iteration will mutate one of the vaiables to its opposite.
        # after finish all iteration we will get the full probability
        for iteration in range(2 ** len(varyingVariables)):
            current_truth_values = get_all_possible_truth_values[iteration]

            #Setting new values to varying variables
            for index, var in enumerate(varyingVariables):
                table_of_variables[var] = str(current_truth_values[index])

            prob = self.get_every_probability_of_the_model(table_of_variables)
            all_variables_probability.extend([prob])

        prob = self.get_value(all_variables_probability)
        return prob

    def data_perimeter(self, tab, length):
        return list(product([True, False], repeat=length))

    def get_value(self, arr):
        sum = 0
        for i in arr:
            prod = 1
            for j in i:
                prod *= j
            sum += prod
        return sum

    def printTableGraph(self):
        for var in self.graph:
            node = self.graph[var]
            print("NODE: {} - PARENT: {} CHILDREN: {} ".format(node.name, node.parents, node.children))


'''
Question 1.2.1
This NaiveBayesClassifier class build based on the probabilistic_learning.py
Data was used from UCI and choose breast-cancer
'''
from collections import defaultdict
from math import log, exp


class NaiveBayesClassifier():
    '''
    For this question choose multionmal naive bayes classifier with laplace smoothing.
    two method used one is train_model and another one is predict_model
    '''
     
    def __init__(self):
        self.priors_probability = None
        self.probability_of_evidence = None

    
    def train_model(self, X, y):
        '''
        here train method will fits the model with the training data set.
        training instace is X and class level is y
        supervised naive bayes model
        used laplace smooth to make all posterior probability to non-zero
        '''

        def calculate_priors_probability(class_level_list):
            """
            here calculate_priors_probability method will take list of class labels then
            It calculates the class priors and fits them to the classifier.
            """
            prior_probability_dict = defaultdict(int)
            for class_label in class_level_list:
                prior_probability_dict[class_label] += 1
            self.priors_probability = dict(prior_probability_dict)
            #print('Prior Probability:',self.priors_probability)
       
        def calculate_probability_of_evidence(priors_prob_dict, instance_list, class_level_list):
            """
            the calculate_probability_of_evidence method takes a dictionary of prior probabilities for class labels,
            list of instance values for each attribute and a list of class labels then it will calculateand fits posterior probabilities to the classifier.
            """
            # Initialize a list of dictionaries for each attribute
            posteriors_dict_list = [dict() for x in range(len(instance_list))]

            # Initialize a default dictionaries for each class label, for each attribute dictionary
            for attribute_dictionary in posteriors_dict_list:

                for class_label in priors_prob_dict.keys():

                    # Adding and start at 1 for Laplace smoothing
                    attribute_dictionary[class_label] = defaultdict(lambda:1)

            # Counting the number of instances for each conditional probability
            for col in range(len(instance_list)):
                for row in range(len(instance_list[col])):

                    posteriors_dict_list[col][class_level_list[row]][instance_list[col][row]] += 1

                # Keeping track of all the attribute possibilites
                attribute_set = set()
                for label in posteriors_dict_list[col].keys():
                    for attr in posteriors_dict_list[col][label].keys():
                        attribute_set.add(attr)

                # Adding 1 with the attributes (Laplace Smoothing) when no occurances found for a given class
                for label in posteriors_dict_list[col].keys():
                    for attr in attribute_set:
                        if attr not in posteriors_dict_list[col][label].keys():

                            # Adding and Start at 1 for Laplace smoothing
                            posteriors_dict_list[col][label][attr] = 1

            self.probability_of_evidence = posteriors_dict_list
            #print('Posterior Probability:',self.probability_of_evidence)


        # Fitting the prior and posterior probabilities to the model
        calculate_priors_probability(y)
        calculate_probability_of_evidence(self.priors_probability, X, y)

    def predict_model(self, test_set):
        """
        This predict_model method will Predicts the class for a set of instances
        based on previously buit trained supervised Naive Bayes model and will
        Returns a list of class predictions.
        """
        if (self.priors_probability is None or self.probability_of_evidence is None):
            raise ValueError("Naive Models model has not been fit.")

        predictions = []
        number_of_test_instances = len(test_set[0])

        # Calculiting a prediction for each instance in the test set
        for test_row in range(number_of_test_instances):
            label_predict_probs = []

            # Calculating prediction probability for each class label
            for label in self.priors_probability.keys():
                label_count = self.priors_probability[label]

                # Calculating Prior log probability log(P(label))
                label_prob = log(label_count / number_of_test_instances)

                # Adding all the prediction probability and log(posterior probabilities) to avoid underfit then
                # Dividing by the total number of labels + total number of attribute values (Laplace Smoothing)
                for test_col in range(len(test_set)):
                    attr = test_set[test_col][test_row]

                    posterior_prob = self.probability_of_evidence[test_col][label][attr] / \
                            (label_count + len(self.probability_of_evidence[test_col][label]))

                    label_prob += log(posterior_prob)

                # Turn log probabilitiy back in probability
                label_prob = exp(label_prob)
                label_predict_probs.append((label_prob, label))

            # Sorting the predictions from high-low and predict the label with the highest probability
            label_predict_probs.sort(reverse=True)
            predictions.append(label_predict_probs[0][1])

        return predictions


import pandas as pd

def preprocess_data(csv_file_path):
    """
    Reads and processes a csv data file.
    """
    df = pd.read_csv(csv_file_path, header=None)
    print('BREAST CANCER DATASET DIMENTION : {}'.format(df.shape) )

    # Adding to the list of each instance for each attribute
    instance_list = []
    if ((len(df.columns) > 1)):
        for attribute_index in range(0, (len(df.columns) - 2)):
            instance_list.append(df[attribute_index].tolist())

    for index in range (0, len(instance_list)):
        instance_list[index] = [str(i) for i in instance_list[index]]

    class_level_list = []
    if ((len(df.columns) > 0)):
        class_level_list = df[(len(df.columns) - 1)].tolist()
    class_level_list = [str(i) for i in class_level_list]

    number_of_unique_class_level = len(set(class_level_list))

    #Returning a tuple of: 2D list of instances, list of class labels, number of unique labels.
    return instance_list, class_level_list, number_of_unique_class_level


def evaluate_model(predicted_classes, actual_classes):
    """
    the below evaluate_model method will Evaluates the number of correct
    predictions made by a Multinomial Naive Bayes classifier and will returns
    an accuracy of score between [0,1].
    """
    number_of_correct_prediction = 0
    for test in range(len(predicted_classes)):
        if predicted_classes[test] == actual_classes[test]:
            number_of_correct_prediction += 1
    return number_of_correct_prediction / len(predicted_classes)


def test_model_and_print_results(dataset_csv_file_path):
    """
    THe test_model_and_print_results method will trains and evaluates the
    Multinomial Naive Bayes learner and prints an accuracy score
    """
    #calling preprocess_data method
    data = preprocess_data(dataset_csv_file_path)
    #calling NaiveBayesClassifier class and creating object
    NB = NaiveBayesClassifier()
    #calling train_model function
    NB.train_model(data[0], data[1])
    #calling predict_model function
    predicted_classes = NB.predict_model(data[0])
    #calling evaluate_model function
    acc = evaluate_model(predicted_classes, data[1])

    print('ACCURACY OF THE MODEL: '+ '{0:.2f}'.format(acc * 100) + '\nFOR ' + dataset_csv_file_path.split('/')[-1] \
          +  ' WITH ' + str(len(predicted_classes)) + ' INSTANCES')

 
#Question 1.2.2

'''
Question 1.2.1 used naive bayes multinomial classifier with the help of probabilistic_learning.py
But here with the help of learning.py file and from the Dataset class this was implemented.
also here took helped from third party library
'''

import matplotlib.pyplot as plt
import seaborn as sns
'exec(%matplotlib inline)'

#LOADING DATA FROM DIR
csv_file_path = 'E:/MSc/KR/kr_test/aima-python/A2_COMP9016_Alom_Mohammed_R00144214/data/breast_cancer.csv'
#Reading the file
uci_breast_cancer_data = pd.read_csv(csv_file_path)


def question_1_2_2():
    '''
    Different data visualization of the breast cancer data and there relationship 
    '''
    #Visualize the data columns
    uci_breast_cancer_data.head()    
    
    #Summarize the data
    uci_breast_cancer_data.describe()
    
    #Visualize the average distance over all the data
    sns.displot(uci_breast_cancer_data['mean_radius'])   
    sns.displot(uci_breast_cancer_data['mean_texture'])
    
    #Distribution plot appears to be normal with a slight skew   
    uci_breast_cancer_data.plot.scatter(x='mean_radius', y='mean_texture');
    #uci_breast_cancer_data.plot.scatter(x='mean_radius', y='mean_texture', c='red');
    
    #Distance around two dimentional shape
    sns.displot(uci_breast_cancer_data['mean_perimeter'])
     
    #average density of hte data
    sns.displot(uci_breast_cancer_data['mean_area'])
     
    #average important patterns in the data
    sns.displot(uci_breast_cancer_data['mean_smoothness'])
    #Distribtuion appears normal
    
    #the pair plots will provide the data to see realtionships between two variables and clear linear realtionship.
    sns.pairplot(uci_breast_cancer_data[['mean_smoothness','mean_area', 'mean_perimeter', 'mean_texture','mean_radius']],palette = sns.color_palette("GnBu_d"), height=2.5)
    
    #Use correlation heat map matrix to see linear realtionship between variables
    corr = uci_breast_cancer_data.corr()
    sns.heatmap(corr, xticklabels=corr.columns.values, yticklabels=corr.columns.values)
    
    plt.show()

'''
Question 1.2.1 used naive bayes multinomial classifier with the help of probabilistic_learning.py
But here with the help of learning.py file and from the Dataset class this was implemented.
also here took helped from third party library
'''
from sklearn.decomposition import PCA
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.naive_bayes import GaussianNB
from sklearn.metrics import confusion_matrix
from sklearn.neighbors import KNeighborsClassifier

def navieBayesLearnerEvaluatePerformance():
    
    #Split the data into independent and dependent variables
    X = uci_breast_cancer_data.iloc[:, : -1].values
    y = uci_breast_cancer_data.iloc[:, -1].values
    
    #Use PCA(Principal Component Analysis) to reduce variables 
    # due to some show linear correlation to each other   
    pca = PCA(n_components=2)
    
    #Scale data    
    scaler = StandardScaler()
    X = scaler.fit_transform(X)  
    #X  
    #Use the PCA, to reduce variables. This prevents overfitting as well
    X = pca.fit_transform(X)
    
    #Split dataset into training and testing 
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size = 0.2)
    
    #Applying Naive Bayes Classification algorithm to find out prediction and accuracy  
    naive_bayes = GaussianNB()
    naive_bayes.fit(X_train, y_train)
    y_predicted = []
    y_predicted = naive_bayes.predict(X_test)   
    #View accuracy using confusion matrix    
    confusion_matrix(y_test,y_predicted)    
    #Print Accuracy of Naive Bayes Algorithim
    print("ACCURACY OF NAIVE BAYES:", (36+70)/ (36+70+1+7))
    
    #Apply Random Forest Algorithim to find prediction and accuracy  
    random_forest = RandomForestClassifier(n_estimators=100, max_depth=2,random_state=0)
    random_forest.fit(X_train,y_train)
    y_predicted = []
    y_predicted = random_forest.predict(X_test)     
    #Print Accuracy of Random Forest Algorithim
    print("ACCURACY OF RANDOM FOREST:", (38 + 68)/ (38+68+3+5))
        
    #Applying KNN Classification to find out the prediction as well as accuracy   
    KNN = KNeighborsClassifier()
    KNN.fit(X_train,y_train)
    y_predicted = []
    y_predicted = KNN.predict(X_test)    
    #View accuracy using confusion matrix
    confusion_matrix(y_test,y_predicted)   
    #Print Accuracy of KNN Algorithim
    print("ACCURACY OF KNN:", (37 + 68)/ (37+68+3+6))
    

def main(): 
    print('\n=========================Question 1.1.2=======================\n')
    
    structure_filename ='E:/MSc/KR/kr_test/aima-python/A2_COMP9016_Alom_Mohammed_R00144214/data/structure.json' #sys.argv[1]
    values_filename = 'E:/MSc/KR/kr_test/aima-python/A2_COMP9016_Alom_Mohammed_R00144214/data/values.json'#sys.argv[2]
    queries_filename = 'E:/MSc/KR/kr_test/aima-python/A2_COMP9016_Alom_Mohammed_R00144214/data/queries.json'#sys.argv[3]

    try:
        with open(structure_filename, 'r') as f:
            structure = json.load(f)
        with open(values_filename, 'r') as f:
            values = json.load(f)
        with open(queries_filename, 'r') as f:
            queries = json.load(f)
    except IOError:
        raise IOError("INPUT FILE NOT FOUND")

    bayesian_network = BayesNode(structure, values, queries)
    bayesian_network.build_Bayesian_Network()
    answers = bayesian_network.probabilistic_inference()
    print('ANSWER :\n', answers, '\n')
        
    print('\n========================Question 1.2.1========================\n')
    
    test_model_and_print_results('data/breast-cancer.csv')
    
    print('\n=======================Question 1.2.2=========================\n')
    
    question_1_2_2()
    navieBayesLearnerEvaluatePerformance()
    

if __name__ == "__main__":
    main()
