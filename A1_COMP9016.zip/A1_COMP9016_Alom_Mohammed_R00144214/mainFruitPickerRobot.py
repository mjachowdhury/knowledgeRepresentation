# -*- coding: utf-8 -*-
"""
Created on Sat Oct 24 02:39:44 2020

@author: Mohammed Alom - R00144214
"""
'''
Code from line 10 to 13 was taken from the lab 1 soluation.
'''
import os, sys, inspect
current_dir = os.path.dirname(os.path.abspath(inspect.getfile(inspect.currentframe())))
parent_dir = os.path.dirname(current_dir)
sys.path.insert(0, parent_dir)

#importing packages and modules
from garden.garden import Run_Model_Based_Agent_Robot, Run_Random_Agent_Robot, Run_Simple_Reflex_Agent_Robot
import matplotlib.pyplot as plt
import time
from search import GraphProblemStochastic,and_or_graph_search,breadth_first_graph_search,depth_first_graph_search,breadth_first_tree_search,iterative_deepening_search,depth_limited_search,astar_search,InstrumentedProblem,GraphProblem
from aimaModifiedFunction.aimaModifiedFunction import UndirectedGraph  
from twoDGraphGenarator.twoDGraphGenarator import polygon_2D_visibility_graph, randomSelect2DPolygonGraph

'''
This class written from aima-python directory and some code modified and added few more functions
'''
class UninformedAndInformedSearchCompare:
    
    #This function written from aima-python directory search.py and some code modified 
    def compare_searchers(self,problems, header,
                      searchers=[breadth_first_graph_search,
                                 depth_first_graph_search,
                                 breadth_first_tree_search,
                                 iterative_deepening_search,
                                 depth_limited_search,
                                 astar_search]):
        def do(searcher, problem):
            problemName = InstrumentedProblem(problem)
            begining_Time = time.time()
            value = searcher(problemName)
            total_time = time.time() - begining_Time
            
            print('------------------------------------------------------------')
            print('Name',searcher)
            #print('Path One Node To Another Node: ',value.path())
            #print('Total Cost To Reach Goal: %.2f'%value.path_cost)
            print('------------------------------------------------------------')
            x_Cordinate,y_Cordinate = [],[]
            graph_Path_Design({'start':problem.graph.init,'goal':problem.graph.fin},graph_2D_visibility.listAllPolygonsEdges())
            for i in value.path():
                x_Cordinate.append(i.state[0])
                y_Cordinate.append(i.state[1])
            plt.title((searcher),loc='center')
            plt.plot(x_Cordinate,y_Cordinate,color='r')
            plt.show()
            return problemName,total_time,value.path_cost
        
        #finding the average 
        for searchName in searchers:
            total_node,total_success_rate,total_goal_success_rate,total_time_to_reach_goal,total_cost = 0,0,0,0,0
            for problemName in problems:
                soluation = do(searchName,problemName)
                total_node += soluation[0].states
                total_success_rate += soluation[0].succs
                total_goal_success_rate += soluation[0].goal_tests
                total_time_to_reach_goal += soluation[1]
                total_cost += soluation[2]
            
            print('Name',(searchName))
            print('------------------------------------------------------------')
            print(f'{"Total States:":40}', total_node)
            print(f'{"Total Success Rate:":40}', total_success_rate)
            print(f'{"Total Goal Success Rate:":40}', total_goal_success_rate)
            print(f'{"Total Time Took To Reach To Goal:":40}',total_time_to_reach_goal)
            print(f'{"Total Cost:":40}',total_cost)

    #This function written from aima-python directory search.py and some code modified 
    def compare_graph_searchers(self,problems):
        """Prints a table of search results."""
        self.compare_searchers(problems,
                        header=['Searcher', 'Total Successors\tTotal Success Rate\tTotal States\tTotal Goal Success Rate','\tTotal Time'])

#This function will draw the 2D graphs and draw a red line from home to destination path  
def graph_Path_Design(states,edges,choice=1):
    plt.xlabel('x - axis') 
    plt.ylabel('y - axis')
    plt.text(states['start'][0],states['start'][1],'S',fontsize=14,color='r',horizontalalignment='right')
    plt.text(states['goal'][0],states['goal'][1],'G',fontsize=14,color='g',horizontalalignment='left')
    plt.scatter([states['start'][0],states['goal'][0]],[states['start'][1],states['goal'][1]],5,color='b')

    if choice == 1:
        for edge in edges:
            x_Cordinate,y_Cordinate = [edge[0][0],edge[1][0]],[edge[0][1],edge[1][1]]
            plt.plot(x_Cordinate,y_Cordinate,color='k',marker='.',markersize=10,markerfacecolor='blue',linewidth=1)

    elif choice == 2:
        for i in g:
            for j in g[i].keys():
                plt.plot([i[0],j[0]],[i[1],j[1]],color='b',marker='.',markersize=10,markerfacecolor='k',linewidth=0.1)

    plt.scatter([states['start'][0]],[states['start'][1]],5,color='b',label='S({},{})'.format(states['start'][0],states['start'][1]))
    plt.scatter([states['goal'][0]],[states['goal'][1]],5,color='b',label='G({},{})'.format(states['goal'][0],states['goal'][1]))
    plt.legend(loc=4)   
    if choice == 2:
        plt.show()


store_all_2DGraphs = []      
store_all_start_and_finish_state = []  
store_edge_all_polygons_for_all_graphs = []            
begining_Time = time.time()
for i in range(1):
    states,polygons = randomSelect2DPolygonGraph()
    graph_2D_visibility = polygon_2D_visibility_graph(polygons,states['start'],states['goal'])
    store_edge_all_polygons_for_all_graphs.append(graph_2D_visibility.listAllPolygonsEdges())
    graph = graph_2D_visibility.create2DVisibilityPolygonGraph()
    store_all_2DGraphs.append(graph)
    store_all_start_and_finish_state.append((states['start'],states['goal']))
#print("Total Time taken to create Visibility Graphs: ",(time.time() - begining_Time))

all2DGraph = []
index = 0
for eachGraph in store_all_2DGraphs:
    graph2D = UndirectedGraph(store_all_start_and_finish_state[index][0],store_all_start_and_finish_state[index][1],eachGraph)
    index += 1
    graph2D.locations = {}
    for i in eachGraph:
        graph2D.locations[i] = i
    all2DGraph.append(graph2D)

if __name__=='__main__':
    #Here each agents will run in the both environment and display the result details 
    print('-------------Part One-----------------')
    print('===Fruit Picker Robot Agents Details===')
    print('-----------------------------------------\n')
    
    print('Model Based Agent Run on the First Environment')
    Run_Model_Based_Agent_Robot("environmentModel/environment1.txt")
    print('------------------------------------------------------\n')
    
    print('Model Based Agent Run on the Second Environment')
    Run_Model_Based_Agent_Robot("environmentModel/environment2.txt")
    print('------------------------------------------------------\n')
    
    print('Random Based Agent Run on the First Environment')
    Run_Random_Agent_Robot("environmentModel/environment1.txt")
    print('------------------------------------------------------\n')
    
    print('Random Based Agent Run on the Second Environment')
    Run_Random_Agent_Robot("environmentModel/environment2.txt")
    print('------------------------------------------------------\n')
    
    print('Simple Reflex Based Based Agent Run on the First Environment')
    Run_Simple_Reflex_Agent_Robot("environmentModel/environment1.txt")
    print('------------------------------------------------------\n')
    
    print('Simple Reflex Based Based Agent Run on the Second Environment')
    Run_Simple_Reflex_Agent_Robot("environmentModel/environment2.txt")
    print('------------------------------------------------------\n')
    
    print('*********************************************************')
    print('--------------------Part 2 ------------------------------')
    print('Uninformed and Informed Search Algorithams Details')
    print('---------------------------------------------------------\n')
    search_result = UninformedAndInformedSearchCompare()
    search_result.compare_graph_searchers([GraphProblem(graph.init,graph.fin, graph) for graph in all2DGraph])
     