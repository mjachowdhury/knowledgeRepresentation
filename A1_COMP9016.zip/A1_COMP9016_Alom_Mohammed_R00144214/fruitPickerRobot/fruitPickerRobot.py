# -*- coding: utf-8 -*-
"""
Created on Sat Oct 24 02:11:49 2020

@author: Mohammed Alom - R00144214
"""
'''
Code from line 10 to 13 was taken from the lab 1 soluation.
'''
import os, sys, inspect
current_dir = os.path.dirname(os.path.abspath(inspect.getfile(inspect.currentframe())))
parent_dir = os.path.dirname(current_dir)
sys.path.insert(0, parent_dir)
 
'''
This FruitPicker class was written and idea took from the aima-python agents.py from the
Environment Class, VacuumEnvironment class, TrivialVacuumEnvironment and GraphicEnvironment class and Direction class.
'''
"""
    Abstract class representing an Environment. 'Real' Environment classes
    inherit from this. Your Environment will typically need to implement:
        percept:           Define the percept that an agent sees.
        execute_action:    Define the effects of executing an action.
                           Also update the agent.performance slot.
   The environment keeps a list of .things and .agents (which is a subset
   of .things). Each agent has a .performance slot, initialized to 0.
   Each thing has a .location slot, even though some environments may not
   need this.
"""
class FruitPicker(object):
   
	Go_Up = 0
	Go_Right = 1
	Go_Down = 2
	Go_Left = 3
	Number_Of_Directions = 4
	Garden = (1, 1)
	Robot_Move = 0
	Robot_Turn_Right = 1
	Robot_Turn_Left = 2
	Robot_Collect_Fruits = 3
	Robot_Turn_Off = 4

	def __init__(self):
		self.Position = self.Garden
		self.Direction = self.Go_Up

	def Turn_Robot(self, direction):
		if direction == 1:
			self.Direction = (self.Direction + 1) % self.Number_Of_Directions
		else:
			self.Direction = (self.Direction - 1 + self.Number_Of_Directions) \
							% self.Number_Of_Directions

	def Get_Sense_In_Front(self):
		x_Cordinate, y_Cordinate = self.Position
		if self.Direction == self.Go_Up:
			y_Cordinate += 1
		elif self.Direction == self.Go_Right:
			x_Cordinate += 1
		elif self.Direction == self.Go_Down:
			y_Cordinate -= 1
		else:
			x_Cordinate -= 1
		return (x_Cordinate, y_Cordinate)
	

	def Get_Sense_Fence(self, garden_Map):
		x_Cordinate, y_Cordinate = self.Get_Sense_In_Front()
		if x_Cordinate <= 0 or x_Cordinate >= len(garden_Map[y_Cordinate]) - 1:
			return True
		if y_Cordinate <= 0 or y_Cordinate >= len(garden_Map) - 1:
			return True
		if garden_Map[y_Cordinate][x_Cordinate].State == 'w':
			return True
		else:
			return False
		
	def Get_Sense_Fruits(self, garden_Map):
		x_Cordinate, y_Cordinate = self.Position
		if garden_Map[y_Cordinate][x_Cordinate].State == 'f':
			return True
		else:
			return False
	
	def Get_Sense_Garden(self):
		return self.Position == self.Garden

	def Move_Robot(self, garden_Map):
		if self.Get_Sense_Fence(garden_Map):
			return False		
		x_Cordinate, y_Cordinate = self.Get_Sense_In_Front()
		if x_Cordinate <= 0 or x_Cordinate >= len(garden_Map[y_Cordinate]) - 1:
			return False
		if y_Cordinate <= 0 or y_Cordinate >= len(garden_Map) - 1:
			return False
		self.Position = (x_Cordinate, y_Cordinate)
		return True
	
	def Collect_Fruits(self, garden_Map):
		x_Cordinate, y_Cordinate = self.Position
		garden_Map[y_Cordinate][x_Cordinate].Collect_Fruit()
		
	def Agent(self, garden_Map):
		return self.Robot_Turn_Off

	def Run(self, garden_Map):
		number_Of_Actions = 0	
		while True:
			action = self.Agent(garden_Map)
			number_Of_Actions += 1
			if number_Of_Actions > 500: #setting the robot action 500 times
				return number_Of_Actions;
			if action == self.Robot_Move:
				self.Move_Robot(garden_Map)
			elif action == self.Robot_Turn_Right:
				self.Turn_Robot(1)
			elif action == self.Robot_Turn_Left:
				self.Turn_Robot(0)
			elif action == self.Robot_Collect_Fruits:
				self.Collect_Fruits(garden_Map)
			elif action == self.Robot_Turn_Off:
				return number_Of_Actions
	
 