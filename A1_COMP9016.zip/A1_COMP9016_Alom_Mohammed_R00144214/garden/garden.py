# -*- coding: utf-8 -*-
"""
Created on Sat Oct 24 02:29:00 2020

@author: Mohammed Alom - R00144214
"""
'''
Code from line 10 to 13 was taken from the lab 1 soluation.
'''
import os, sys, inspect
current_dir = os.path.dirname(os.path.abspath(inspect.getfile(inspect.currentframe())))
parent_dir = os.path.dirname(current_dir)
sys.path.insert(0, parent_dir)

#importing packages and modules
from agents.agents import Simple_Reflex_Agent, Model_Based_Agent, Random_Reflex_Agent
#from agents import *
'''
This class was written idea took from the aima-python directory agents.py 
This class has agent 2D mode environment and three agents functionality setup
'''                 
class Garden(object):
    """An Agent is a subclass of Thing with one required instance attribute 
    (aka slot), .program, which should hold a function that takes one argument,
    the percept, and returns an action. (What counts as a percept or action 
    will depend on the specific environment in which the agent exists.)
    Note that 'program' is a slot, not a method. If it were a method, then the
    program could 'cheat' and look at aspects of the agent. It's not supposed
    to do that: the program can only look at the percepts. An agent program
    that needs a model of the world (and of the agent itself) will have to
    build and maintain its own model. There is an optional slot, .performance,
    which is a number giving the performance measure of the agent in its
    environment."""
    
    def __init__(self, state):
        self.State = state

    def Collect_Fruit(self):
        if self.State == 'f':
            self.State = 'c'

#This function will read the model environment from the file           
def Garden_Map_Environment(filename):
    garden_Map = []
    map_File = open(filename)
    try:
        for i in range(0,10):
            eachLine = map_File.readline( )
            eachRow = []
            for state in eachLine:
                if state != '\t' and state != '\n':
                    eachRow.append(Garden(state))                   
            garden_Map.insert(0,eachRow)		
    finally:
        map_File.close()
        return garden_Map
#This function will get the total fruits from the garden
def Number_Of_Fruits(garden_Map):
    num = 0
    for row in garden_Map:
        for garden in row:
            if garden.State == 'f':
                num += 1
    return num

#This function will draw on the screen 2D garden map environemnt wiht walls/fence and fruits
def Print_2D_Graph(garden_Map):
    for i in range(len(garden_Map) - 1, -1, -1):
        line = ''
        for j in range(len(garden_Map[0])):
            garden = garden_Map[i][j]
            if garden.State == 'w': #W meand walls in the world
                line = line + 'W'
            elif garden.State == 'f': # f means fruits in the world
                line = line + 'F'
            else:
                line = line + ' '
            line = line + ' '
        print (line)

def Run_Simple_Reflex_Agent_Robot(garden_Map_File):
    """
    [Figure 2.10]Artificial Intelligence Modern Approach Chapter 2 3rd Edition
    This agent takes action based solely on the percept.
    #This is Simple Reflx Robot which will read the two 2D model environments from the file and will display the result details.
    """
    garden_Map = Garden_Map_Environment(garden_Map_File)
    original_Number_Of_Fruits = Number_Of_Fruits(garden_Map)    
    agent = Simple_Reflex_Agent() # Calling simple reflex agent instance
    numOfAction = agent.Run(garden_Map)    
    final_Number_Of_Fruits_Collected = original_Number_Of_Fruits - Number_Of_Fruits(garden_Map)
    #calling function
    Agent_Result_Summary("Simple-Reflex Agent", original_Number_Of_Fruits, final_Number_Of_Fruits_Collected, numOfAction, garden_Map)

    
def Run_Model_Based_Agent_Robot(garden_Map_File):
    """
    #This is Simple Reflx Robot which will read the two 2D model environments from the file and will display the result details.
    [Figure 2.12]Artificial Intelligence Modern Approach Chapter 2 3rd Edition
    This agent takes action based on the percept and state.    
    An agent that keeps track of what locations are no fruits or has fruits.
    >>> agent = ModelBasedVacuumAgent()
    >>> environment = TrivialVacuumEnvironment()
    >>> environment.add_thing(agent)
    >>> environment.run()
    """
    garden_Map = Garden_Map_Environment(garden_Map_File)
    original_Number_Of_Fruits = Number_Of_Fruits(garden_Map)    
    agent = Model_Based_Agent() #calling model based agent instance
    numOfAction = agent.Run(garden_Map)    
    final_Number_Of_Fruits_Collected = original_Number_Of_Fruits - Number_Of_Fruits(garden_Map)
    Agent_Result_Summary("Model-Based Agent", original_Number_Of_Fruits, final_Number_Of_Fruits_Collected, numOfAction, garden_Map)

    
def Run_Random_Agent_Robot(garden_Map_File):
    """
    Randomly choose one of the actions from the vacuum environment.
    >>> agent = RandomVacuumAgent()
    >>> environment = TrivialVacuumEnvironment()
    >>> environment.add_thing(agent)
    >>> environment.run()
    #This is Simple Reflx Robot which will read the two 2D model environments from the file and will display the result details.
    """
    total_Sum_Of_Actions = 0
    total_Sum_Of_Fruit_Collection = 0
    total_Sum_Of_Fruits = 0
    agent = Random_Reflex_Agent(0.5,0.5,0.1,0.8) # Agent moving actions and Calling Random reflex agent instance
    '''
    here agent will take 60 action and within 60 action agent perfomance will measure the parameter can be changed
    '''
    for i in range (0,60):
        garden_Map = Garden_Map_Environment(garden_Map_File)
        original_Number_Of_Fruits = Number_Of_Fruits(garden_Map)
        numOfAction = agent.Run(garden_Map)
        final_Number_Of_Fruits_Collected = original_Number_Of_Fruits - Number_Of_Fruits(garden_Map)
        total_Sum_Of_Actions += numOfAction
        total_Sum_Of_Fruit_Collection += final_Number_Of_Fruits_Collected
        total_Sum_Of_Fruits   += original_Number_Of_Fruits
    Agent_Result_Summary("Rondom-Relex Agent(Average) ", total_Sum_Of_Fruits/60, total_Sum_Of_Fruit_Collection/60, total_Sum_Of_Actions/60, garden_Map)

#this function will display on the screen 3 agents details and also will write in the project Result directory agents details text file
def Agent_Result_Summary(FruitPicker, original_Number_Of_Fruits, final_Number_Of_Fruits_Collected, numOfAction, garden_Map_Cleared):
    output = open(str('Results/'+ FruitPicker + ' Result.txt'), 'a')
    
    print("------------------------------------------------------------------\n")
    output.write("*****************************************************\n")
    for i in range(len(garden_Map_Cleared) - 1, -1, -1):
        line = ''
        for j in range(len(garden_Map_Cleared[0])):
            garden = garden_Map_Cleared[i][j]
            if garden.State == 'c':
                line += ' '
            else:
                line += garden.State
            line += ' '
        print (line)
        output.write(line + '\n')
    #Display on the screen
    print("-------------------\n")
    print(f'{"Agent/Robot Name:":40}' + FruitPicker)
    print(f'{"Total Fruits in the Garden:":40}' + str(original_Number_Of_Fruits))
    print(f'{"Total Fruits Collected by Robot:":40}' + str(final_Number_Of_Fruits_Collected))
    print(f'{"Total Actions Took/Cost:":40}' + str(numOfAction))
    print(f'{"Agent/Robot Efficiency:":40}'  +str(final_Number_Of_Fruits_Collected / numOfAction))
    print(f'{"Agent/Robot Fruits Collection Percent:":40}' + str(final_Number_Of_Fruits_Collected / original_Number_Of_Fruits) + '\n')
    
    #Writing in the text file
    output.write("-------------------\n")
    output.write(f'{"Agent Name:":40}' + FruitPicker + '\n')
    output.write(f'{"Total Fruits in the Garden:":40}' + str(original_Number_Of_Fruits) + '\n')
    output.write(f'{"Total Fruits Collected by Agent:":40}' + str(final_Number_Of_Fruits_Collected) + '\n')
    output.write(f'{"Total Actions Took/Cost:":40}' + str(numOfAction) + '\n')
    output.write(f'{"Agent Efficiency:":40}'+ str(final_Number_Of_Fruits_Collected / numOfAction) + '\n')
    output.write(f'{"Agent Fruits Collection Percent:":40}' + str(final_Number_Of_Fruits_Collected / original_Number_Of_Fruits) + '\n\n')
    output.close()