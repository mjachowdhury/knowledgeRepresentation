# -*- coding: utf-8 -*-
"""
Created on Sat Oct 24 02:17:30 2020

@author: Mohammed Alom - R00144214
"""
'''
Code from line 10 to 13 was taken from the lab 1 soluation.
'''
import os, sys, inspect
current_dir = os.path.dirname(os.path.abspath(inspect.getfile(inspect.currentframe())))
parent_dir = os.path.dirname(current_dir)
sys.path.insert(0, parent_dir)

#importing packages and modules
from fruitPickerRobot.fruitPickerRobot import FruitPicker

#==================Model Based Agent Class Start=================             
class Model_Based_Agent(FruitPicker):
    '''
    This class created from the agents.py according the idea from ModelBasedVacuumAgent method 
    [Figure 2.12]Artificial Intelligence Modern Approach Chapter 2 3rd Edition
    This agent takes action based on the percept and state.   
    An agent that keeps track of what locations are no fruits or has fruits.
    >>> agent = ModelBasedVacuumAgent()
    >>> environment = TrivialVacuumEnvironment()
    >>> environment.add_thing(agent)
    >>> environment.run()
    ''' 
    def __init__(self):
        FruitPicker.__init__(self)
        self.bit0 = False
        self.bit1 = True
        self.bit2 = True

    def SetState(self,bit0, bit1, bit2):
        self.bit0 = bit0
        self.bit1 = bit1
        self.bit2 = bit2
        
    def Agent(self, garden_Map):
        isFence = self.Get_Sense_Fence(garden_Map)
        isFruit = self.Get_Sense_Fruits(garden_Map)
        isGarden = self.Get_Sense_Garden()
        #agents if then conditions
        if isFruit:
            return self.Robot_Collect_Fruits
        elif isGarden and isFence:
            return self.Robot_Turn_Off
        # state condition = 0
        elif not self.bit0 and not self.bit1 and not self.bit2:
            if isFence:
                # set state position = 1
                self.SetState(False,False,True)
                return self.Robot_Turn_Left
            else:
                return self.Robot_Move
            # when state condition = 1
        elif not self.bit0 and not self.bit1 and self.bit2:
            if isFence:
                # set the state position = 6 || 0
                self.SetState(False, False, False)
                return self.Robot_Turn_Left
            else:
                # set the state position = 2
                self.SetState(False,True,False)
                return self.Robot_Move
        # when state condition = 2
        elif not self.bit0 and self.bit1 and not self.bit2:
            # set the state position = 3
            self.SetState(False,True,True)
            return self.Robot_Turn_Left
        # when state condition = 3
        elif not self.bit0 and self.bit1 and self.bit2:
            if isFence:
                # set the state position = 4
                self.SetState(True,False,False)
                return self.Robot_Turn_Right
            else:
                return self.Robot_Move
        # when state condition = 4
        elif self.bit0 and not self.bit1 and not self.bit2:
            if isFence:
                # set the state position = 6
                self.SetState(True,True,False)
                return self.Robot_Turn_Left
            else:
                # set the state position = 5
                self.SetState(True,False,True)
                return self.Robot_Move
        #when state condition = 5
        elif self.bit0 and not self.bit1 and self.bit2:
            #set the state position to home = 0
            self.SetState(False,False,False)
            return self.Robot_Turn_Right
        # when state condition = 6
        elif self.bit0 and self.bit1 and not self.bit2:
            # set the state position to home = 0
            self.SetState(False,False,False)
            return self.Robot_Turn_Left
            
#================Model Based Agent Class End====================
            
        
#======================Random Reflex Agent Class Start===================
'''
A randomized reflex agent that can choose actions randomly based on sensor readings.
An agent that chooses an action at random, ignoring all percepts.
Randomly choose one of the actions from the world environment.
'''
import random
class Random_Reflex_Agent(FruitPicker):
	def __init__(self, chance_Turn_Left,chance_Turn_Right,chance_Turn_Off,probability_Move):
		FruitPicker.__init__(self)
		random.seed()
		self.chance_Turn_Left = chance_Turn_Left
		self.chance_Turn_Right = chance_Turn_Right
		self.chance_Turn_Off = chance_Turn_Off
		self.probability_Move = probability_Move

	def Agent (self, grid):
		isFacingFence = self.Get_Sense_Fence(grid)
		isFruit      = self.Get_Sense_Fruits(grid)
		isHome       = self.Get_Sense_Garden()
       
      #agents if then conditions  
		if isFruit:
			return self.Robot_Collect_Fruits
		else:
			if isFacingFence:
				if isHome:
					if random.uniform (0, 1) < self.chance_Turn_Off:
						return self.Robot_Turn_Off
				if random.uniform(0, 1) < self.chance_Turn_Right:
					return self.Robot_Turn_Right
				else:
				    return self.Robot_Turn_Left
			else:
				if random.uniform(0,1) < self.probability_Move:
					return self.Robot_Move
				else:
					if random.uniform(0, 1) < self.chance_Turn_Right:
						return self.Robot_Turn_Right
					else:
						return self.Robot_Turn_Left           

#=====================Random Reflex Agent Class End =====================
                        

#=====================Simple Reflex Agent Class Start ==================
                        
'''
#A simple memory-less deterministic reflex agent
[Figure 2.8]- Artificial Intelligence Modern Approach Chapter 2 3rd Edition
A reflex agent for the two-state vacuum environment.
'''
class Simple_Reflex_Agent(FruitPicker):
    
	def Agent(self, grid):
		 isFacingFence = self.Get_Sense_Fence(grid)
		 isFruit      = self.Get_Sense_Fruits(grid)
		 isHome       = self.Get_Sense_Garden()
        #agent if then conditions 
		 if isFruit:
		 	return self.Robot_Collect_Fruits
		 else:
		 	if isFacingFence:
		 		if isHome:
		 			return self.Robot_Turn_Off
		 		else:
		 			return self.Robot_Turn_Right
		 	else:
		 		return self.Robot_Move

#====================Simple Reflex Agent Class End ===================== 