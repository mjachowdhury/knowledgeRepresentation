# -*- coding: utf-8 -*-
"""
Created on Sat Oct 24 03:08:19 2020

@author: Mohammed Alom - R00144214
"""
'''
Code from line 10 to 13 was taken from the lab 1 soluation.
'''
import os, sys, inspect
current_dir = os.path.dirname(os.path.abspath(inspect.getfile(inspect.currentframe())))
parent_dir = os.path.dirname(current_dir)
sys.path.insert(0, parent_dir)
sys.path.append('..')

#importing packages and modules
from utils import euclidean_distance
import random
'''
#This class holds all the functions and Algo. to help to generate the 2D polygon graph
'''
class Cordinate: 
    def __init__(self, x_Cordinate, y_Cordinate): 
        self.x_Cordinate = x_Cordinate 
        self.y_Cordinate = y_Cordinate 

class Distance:
    def __init__(self,distanceA,distanceB):
        self.polygons = []
        self.distanceA = distanceA
        self.distanceB = distanceB

    def clear_path_middle(self, pointA, pointB, pointC):
        draw_cross_line = (pointA[0] - pointB[0]) * (pointC[1] - pointB[1]) - (pointA[1] - pointB[1]) * (pointC[0] - pointB[0])
        draw_dot_line = (pointA[0] - pointB[0]) * (pointC[0] - pointB[0]) + (pointA[1] - pointB[1]) * (pointC[1] - pointB[1])
        return draw_cross_line < 0 or draw_cross_line == 0 and draw_dot_line <= 0


    def polygon_2D_convex_hull(self, points):
        start_point = sorted(points)
        convex_hull_points = []
        for point in start_point + start_point[::-1]:
            while len(convex_hull_points) >= 2 and self.clear_path_middle(convex_hull_points[-2], convex_hull_points[-1], point):
                convex_hull_points.pop()
            convex_hull_points.append(point)
        convex_hull_points.pop()
        return convex_hull_points

    def generate_2D_polygons_space(self):
        i = 0
        number = random.randint(15,20)
        of = 200
        #if self.m == 1000:
        #    of = 250
        count_total_polygons = 0
        while(i < self.distanceA):
            j = 0
            while(j < self.distanceB):
                polygon_total_points = []
                for _ in range(number):
                    x_Cordinate,y_Cordinate = random.randint(i,i+99),random.randint(j,j+199)
                    polygon_total_points.append((x_Cordinate,y_Cordinate))
                self.polygons.append(self.polygon_2D_convex_hull(polygon_total_points))
                count_total_polygons+=1
                j += of
            i += (of - 100)
        #print('Total Number of Polygons: ',count_total_polygons)
    
    def get_2D_polygon_state_space(self):
        self.generate_2D_polygons_space()
        return self.polygons

class polygon_2D_visibility_graph:
    
    def __init__(self, polygons, home, destination):
        self.polygons = polygons
        self.home = home
        self.destination = destination

    def calculate_segment(self,pointP, pointQ, pointR): 
        if ( (pointQ.x_Cordinate <= max(pointP.x_Cordinate, pointR.x_Cordinate)) and (pointQ.x_Cordinate >= min(pointP.x_Cordinate, pointR.x_Cordinate)) and 
            (pointQ.y_Cordinate <= max(pointP.y_Cordinate, pointR.y_Cordinate)) and (pointQ.y_Cordinate >= min(pointP.y_Cordinate, pointR.y_Cordinate))): 
            return True
        return False
    
    def start_position(self,pointP, pointQ, pointR):       
        value = (float(pointQ.y_Cordinate - pointP.y_Cordinate) * (pointR.x_Cordinate - pointQ.x_Cordinate)) - (float(pointQ.x_Cordinate - pointP.x_Cordinate) * (pointR.y_Cordinate - pointQ.y_Cordinate)) 
        if (value > 0):   
            return 1
        elif (value < 0): 
            return 2
        else:
            return 0
    
    def do_intersect_2D_polygon(self,pointP1,pointQ1,pointP2,pointQ2):
        input1 = self.start_position(pointP1, pointQ1, pointP2) 
        input2 = self.start_position(pointP1, pointQ1, pointQ2) 
        input3 = self.start_position(pointP2, pointQ2, pointP1) 
        input4 = self.start_position(pointP2, pointQ2, pointQ1) 

        if ((input1 != input2) and (input3 != input4)): 
            return True   
        if ((input1 == 0) and self.calculate_segment(pointP1, pointP2, pointQ1)): 
            return True    
        if ((input2 == 0) and self.calculate_segment(pointP1, pointQ2, pointQ1)): 
            return True    
        if ((input3 == 0) and self.calculate_segment(pointP2, pointP1, pointQ2)): 
            return True    
        if ((input4 == 0) and self.calculate_segment(pointP2, pointQ1, pointQ2)): 
            return True    
        return False

    def listAllPolygonsEdges(self):         
        edges = []
        for pol in self.polygons:
            n = len(pol)
            for i in range(n):
                edges.append((pol[i],pol[(i + 1) % n]))
        return edges

    def getPolygonId(self,vertex):         
        for polyId in range(len(self.polygons)):
            if vertex in self.polygons[polyId]:
                return polyId, self.polygons[polyId].index(vertex)

    def create2DVisibilityPolygonGraph(self):
        all_Vertex_list = []   
        all_Vertex_list.append(self.home)
        for i in self.polygons:
            for j in i:
                all_Vertex_list.append(j)
        all_Vertex_list.append(self.destination)
        edges = self.listAllPolygonsEdges()
        visivility_graph_dic = {}     # visibility graph
        for vertex_1 in all_Vertex_list:
            visivility_graph_dic[vertex_1] = {}
            for vertex_2 in all_Vertex_list:
                if vertex_1 != vertex_2:
                    flag1 = 0
                    if ((vertex_1 != self.home and vertex_1 != self.destination) and (vertex_2 != self.home and vertex_2 != self.destination)):
                        polyId1,i1 = self.getPolygonId(vertex_1)
                        polyId2,i2 = self.getPolygonId(vertex_2)
                        neighbour = len(self.polygons[polyId1])
                        flag1 = 1
                    if flag1 == 0 or (polyId1 != polyId2) or ((polyId1 == polyId2) and (vertex_2 == self.polygons[polyId1][(i1+1)%neighbour] or vertex_2 == self.polygons[polyId1][(i1+neighbour-1)%neighbour])):
                        p1 = Cordinate(vertex_1[0],vertex_1[1])
                        q1 = Cordinate(vertex_2[0],vertex_2[1])
                        flag = 0
                        for e in edges:
                            if (vertex_1 not in e) and (vertex_2 not in e):
                                p2 = Cordinate(e[0][0],e[0][1])
                                q2 = Cordinate(e[1][0],e[1][1])
                                if self.do_intersect_2D_polygon(p1,q1,p2,q2):
                                    flag = 1
                                    break
                        if flag == 0:
                            visivility_graph_dic[vertex_1][vertex_2] = float('%.4f'%(euclidean_distance(vertex_1,vertex_2)))
        return visivility_graph_dic

#This function will select random size of the 2D polygon graph
def randomSelect2DPolygonGraph():
    select = random.randint(1,2)
    if select == 1:
        x_Cordinate,y_Cordinate = 250,500
        states = {'start':(0.0,0.0),'goal':(250.0,500.0)}
    else:
        x_Cordinate,y_Cordinate = 500,1000
        states = {'start':(0.0,0.0),'goal':(500.0,1000.0)}
    p = Distance(x_Cordinate,y_Cordinate)
    polygons = p.get_2D_polygon_state_space()
    return states,polygons
